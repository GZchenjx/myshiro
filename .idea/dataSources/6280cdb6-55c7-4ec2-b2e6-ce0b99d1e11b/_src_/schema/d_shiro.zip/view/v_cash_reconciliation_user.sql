CREATE VIEW v_cash_reconciliation_user AS
  SELECT
    `tcr`.`OrdId`     AS `OrdId`,
    `tcr`.`MerCustId` AS `MerCustId`,
    `tcr`.`UsrCustId` AS `UsrCustId`,
    `tcr`.`CardId`    AS `CardId`,
    `tcr`.`TransAmt`  AS `TransAmt`,
    `tcr`.`TransStat` AS `TransStat`,
    `tcr`.`PnrDate`   AS `PnrDate`,
    `tcr`.`PnrSeqId`  AS `PnrSeqId`,
    `tcr`.`FeeAmt`    AS `FeeAmt`,
    `tcr`.`FeeObj`    AS `FeeObj`,
    `t`.`username`    AS `username`,
    `tcr`.`InDate`    AS `InDate`
  FROM (`d_shiro`.`t_cash_reconciliation` `tcr`
    JOIN `d_shiro`.`t_user` `t`)
  WHERE (`tcr`.`UsrCustId` = `t`.`ipayAccount`);
