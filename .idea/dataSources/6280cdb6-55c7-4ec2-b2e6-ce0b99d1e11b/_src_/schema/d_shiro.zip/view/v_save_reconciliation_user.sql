CREATE VIEW v_save_reconciliation_user AS
  SELECT
    `tsr`.`OrdId`      AS `OrdId`,
    `tsr`.`MerCustId`  AS `MerCustId`,
    `tsr`.`UsrCustId`  AS `UsrCustId`,
    `tsr`.`OrdDate`    AS `OrdDate`,
    `tsr`.`TransAmt`   AS `TransAmt`,
    `tsr`.`TransStat`  AS `TransStat`,
    `tsr`.`GateBusiId` AS `GateBusiId`,
    `tcgb`.`busiName`  AS `busiName`,
    `tsr`.`OpenBankId` AS `OpenBankId`,
    `tcb`.`bankName`   AS `bankName`,
    `tsr`.`OpenAcctId` AS `OpenAcctId`,
    `tsr`.`FeeAmt`     AS `FeeAmt`,
    `t`.`username`     AS `username`,
    `tsr`.`InDate`     AS `InDate`
  FROM (((`d_shiro`.`t_save_reconciliation` `tsr` LEFT JOIN `d_shiro`.`t_user` `t`
      ON ((`tsr`.`UsrCustId` = `t`.`ipayAccount`))) LEFT JOIN `d_shiro`.`t_csc_bankcode` `tcb`
      ON ((`tsr`.`OpenBankId` = `tcb`.`bankCode`))) LEFT JOIN `d_shiro`.`t_csc_gate_busi` `tcgb`
      ON ((`tsr`.`GateBusiId` = `tcgb`.`busiCode`)));
