CREATE VIEW v_t_admin AS
  SELECT
    `ta`.`id`       AS `id`,
    `ta`.`enable`   AS `enable`,
    `ta`.`lastIP`   AS `lastIP`,
    `ta`.`lastTime` AS `lastTime`,
    `ta`.`password` AS `password`,
    `ta`.`roleId`   AS `roleId`,
    `ta`.`userName` AS `userName`,
    `tr`.`name`     AS `roleName`
  FROM (`d_shiro`.`t_admin` `ta` LEFT JOIN `d_shiro`.`t_role` `tr` ON ((`ta`.`roleId` = `tr`.`id`)));
