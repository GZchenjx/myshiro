CREATE VIEW t_user_person_info AS
  SELECT
    `a`.`id`       AS `userId`,
    `a`.`username` AS `uername`,
    `b`.`realName` AS `realName`
  FROM (`d_shiro`.`t_user` `a` LEFT JOIN `d_shiro`.`t_person` `b` ON ((`a`.`id` = `b`.`userId`)));
