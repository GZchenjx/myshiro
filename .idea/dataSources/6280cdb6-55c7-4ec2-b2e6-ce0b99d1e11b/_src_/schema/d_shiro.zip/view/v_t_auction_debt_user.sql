CREATE VIEW v_t_auction_debt_user AS
  SELECT
    `d_shiro`.`t_auction_debt`.`id`                                      AS `id`,
    `d_shiro`.`t_auction_debt`.`debtId`                                  AS `debtId`,
    date_format(`d_shiro`.`t_auction_debt`.`auctionTime`, '%Y-%m-%d %T') AS `auctionTime`,
    `d_shiro`.`t_auction_debt`.`auctionPrice`                            AS `auctionPrice`,
    `d_shiro`.`t_user`.`username`                                        AS `username`,
    `d_shiro`.`t_auction_debt`.`userId`                                  AS `userId`
  FROM (`d_shiro`.`t_auction_debt`
    LEFT JOIN `d_shiro`.`t_user` ON ((`d_shiro`.`t_auction_debt`.`userId` = `d_shiro`.`t_user`.`id`)));
