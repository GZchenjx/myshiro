CREATE VIEW t_success_paying_all_details AS
  SELECT
    `a`.`id`                                                     AS `id`,
    `b`.`id`                                                     AS `payId`,
    `a`.`publisher`                                              AS `publisher`,
    `a`.`borrowTitle`                                            AS `borrowTitle`,
    `a`.`publishTime`                                            AS `publishTime`,
    `b`.`repayPeriod`                                            AS `repayPeriod`,
    ((`b`.`stillInterest` + `b`.`stillPrincipal`) - `b`.`hasPI`) AS `totalPay`,
    ((`b`.`stillInterest` * ((`b`.`stillInterest` + `b`.`stillPrincipal`) - `b`.`hasPI`)) /
     (`b`.`stillInterest` + `b`.`stillPrincipal`))               AS `rate`,
    `b`.`lateDay`                                                AS `lateDay`,
    `b`.`repayStatus`                                            AS `repayStatus`,
    `b`.`repayDate`                                              AS `repayDate`,
    `b`.`realRepayDate`                                          AS `realRepayDate`,
    `b`.`lateFI`                                                 AS `lateFI`
  FROM (`d_shiro`.`t_borrow` `a`
    JOIN `d_shiro`.`t_repayment` `b` ON ((`a`.`id` = `b`.`borrowId`)));
