CREATE VIEW v_trf_reconciliation_user AS
  SELECT
    `ttr`.`OrdId`      AS `OrdId`,
    `ttr`.`InDate`     AS `InDate`,
    `ttr`.`MerCustId`  AS `MerCustId`,
    `ttr`.`UsrCustId`  AS `UsrCustId`,
    `ttr`.`BorrCustId` AS `BorrCustId`,
    `ttr`.`TransAmt`   AS `TransAmt`,
    `ttr`.`TransStat`  AS `TransStat`,
    `ttr`.`PnrDate`    AS `PnrDate`,
    `ttr`.`PnrSeqId`   AS `PnrSeqId`,
    `t`.`username`     AS `username`
  FROM (`d_shiro`.`t_trf_reconciliation` `ttr`
    JOIN `d_shiro`.`t_user` `t`)
  WHERE (`ttr`.`UsrCustId` = `t`.`ipayAccount`);
