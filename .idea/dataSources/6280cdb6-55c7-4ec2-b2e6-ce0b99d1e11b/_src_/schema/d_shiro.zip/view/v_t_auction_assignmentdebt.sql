CREATE VIEW v_t_auction_assignmentdebt AS
  SELECT
    `d_shiro`.`t_borrow`.`borrowTitle`                                               AS `borrowTitle`,
    `d_shiro`.`t_borrow`.`id`                                                        AS `borrowId`,
    `d_shiro`.`t_borrow`.`annualRate`                                                AS `annualRate`,
    `d_shiro`.`t_borrow`.`deadline`                                                  AS `deadline`,
    `d_shiro`.`t_borrow`.`borrowAmount`                                              AS `borrowAmount`,
    `d_shiro`.`t_borrow`.`borrowWay`                                                 AS `borrowWay`,
    `d_shiro`.`t_borrow`.`paymentMode`                                               AS `paymentMode`,
    `d_shiro`.`t_user`.`username`                                                    AS `borrowerName`,
    date_format(`d_shiro`.`t_assignment_debt`.`auctionEndTime`, '%Y-%m-%d %H:%i:%s') AS `auctionEndTime`,
    `d_shiro`.`t_invest`.`realAmount`                                                AS `realAmount`,
    `d_shiro`.`t_assignment_debt`.`debtSum`                                          AS `debtSum`,
    `d_shiro`.`t_assignment_debt`.`id`                                               AS `debtId`,
    `d_shiro`.`t_assignment_debt`.`debtLimit`                                        AS `debtLimit`,
    `d_shiro`.`t_assignment_debt`.`alienatorId`                                      AS `alienatorId`,
    `d_shiro`.`t_assignment_debt`.`debtStatus`                                       AS `debtStatus`,
    `d_shiro`.`t_assignment_debt`.`auctionDays`                                      AS `auctionDays`,
    `d_shiro`.`t_assignment_debt`.`auctionBasePrice`                                 AS `auctionBasePrice`,
    `d_shiro`.`t_assignment_debt`.`auctionHighPrice`                                 AS `auctionHighPrice`,
    `d_shiro`.`t_assignment_debt`.`viewpdf_url`                                      AS `viewpdf_url`,
    `d_shiro`.`t_assignment_debt`.`viewpdf_url`                                      AS `download_url`,
    `auctioner`.`username`                                                           AS `auctionName`,
    date_format(
        (`d_shiro`.`t_assignment_debt`.`publishTime` + INTERVAL `d_shiro`.`t_assignment_debt`.`auctionDays` DAY),
        '%Y-%m-%d %H:%i:%s')                                                         AS `remainAuctionTime`,
    `d_shiro`.`t_invest`.`investor`                                                  AS `investor`
  FROM ((((`d_shiro`.`t_assignment_debt`
    LEFT JOIN `d_shiro`.`t_borrow`
      ON ((`d_shiro`.`t_assignment_debt`.`borrowId` = `d_shiro`.`t_borrow`.`id`))) LEFT JOIN `d_shiro`.`t_user`
      ON ((`d_shiro`.`t_borrow`.`publisher` = `d_shiro`.`t_user`.`id`))) LEFT JOIN `d_shiro`.`t_invest`
      ON ((`d_shiro`.`t_invest`.`id` = `d_shiro`.`t_assignment_debt`.`investId`))) LEFT JOIN
    `d_shiro`.`t_user` `auctioner` ON ((`d_shiro`.`t_assignment_debt`.`auctionerId` = `auctioner`.`id`)));
