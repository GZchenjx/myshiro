CREATE VIEW v_t_assignment_debt_success AS
  SELECT
    `d_shiro`.`t_assignment_debt`.`id`                                               AS `id`,
    `d_shiro`.`t_assignment_debt`.`debtSum`                                          AS `debtSum`,
    `d_shiro`.`t_assignment_debt`.`auctionBasePrice`                                 AS `auctionBasePrice`,
    `d_shiro`.`t_assignment_debt`.`debtLimit`                                        AS `debtLimit`,
    `d_shiro`.`t_assignment_debt`.`debtStatus`                                       AS `debtStatus`,
    `d_shiro`.`t_assignment_debt`.`auctionerId`                                      AS `auctionerId`,
    date_format(`d_shiro`.`t_assignment_debt`.`auctionEndTime`, '%Y-%m-%d %H:%i:%s') AS `auctionEndTime`,
    `d_shiro`.`t_assignment_debt`.`auctionHighPrice`                                 AS `auctionHighPrice`,
    `d_shiro`.`t_assignment_debt`.`viewpdf_url`                                      AS `viewpdf_url`,
    `d_shiro`.`t_assignment_debt`.`download_url`                                     AS `download_url`,
    `d_shiro`.`t_borrow`.`borrowTitle`                                               AS `borrowTitle`,
    `d_shiro`.`t_user`.`username`                                                    AS `borrowerName`,
    `alineator`.`username`                                                           AS `username`,
    `d_shiro`.`t_assignment_debt`.`alienatorId`                                      AS `alienatorId`,
    `d_shiro`.`t_borrow`.`annualRate`                                                AS `annualRate`,
    `auctioner`.`username`                                                           AS `auctionerName`,
    `d_shiro`.`t_borrow`.`deadline`                                                  AS `deadline`,
    `d_shiro`.`t_borrow`.`paymentMode`                                               AS `paymentMode`,
    `d_shiro`.`t_borrow`.`borrowAmount`                                              AS `borrowAmount`,
    `d_shiro`.`t_assignment_debt`.`borrowId`                                         AS `borrowId`,
    date_format(`d_shiro`.`t_assignment_debt`.`buyTime`, '%Y-%m-%d %H:%i:%s')        AS `buyTime`
  FROM ((((`d_shiro`.`t_assignment_debt`
    LEFT JOIN `d_shiro`.`t_borrow`
      ON ((`d_shiro`.`t_assignment_debt`.`borrowId` = `d_shiro`.`t_borrow`.`id`))) LEFT JOIN `d_shiro`.`t_user`
      ON ((`d_shiro`.`t_borrow`.`publisher` = `d_shiro`.`t_user`.`id`))) LEFT JOIN `d_shiro`.`t_user` `alineator`
      ON ((`d_shiro`.`t_assignment_debt`.`alienatorId` = `alineator`.`id`))) LEFT JOIN `d_shiro`.`t_user` `auctioner`
      ON ((`d_shiro`.`t_assignment_debt`.`auctionerId` = `auctioner`.`id`)))
  WHERE (`d_shiro`.`t_assignment_debt`.`debtStatus` = 3);
