CREATE VIEW v_t_admin_credit_msg AS
  SELECT
    `te`.`companyName`  AS `companyName`,
    `te`.`userId`       AS `id`,
    `tm1`.`auditStatus` AS `auditStatus1`,
    `tm2`.`auditStatus` AS `auditStatus2`,
    `tm3`.`auditStatus` AS `auditStatus3`,
    `tm4`.`auditStatus` AS `auditStatus4`,
    `tm5`.`auditStatus` AS `auditStatus5`,
    `tm6`.`auditStatus` AS `auditStatus6`
  FROM ((((((`d_shiro`.`t_enterprise` `te` LEFT JOIN `d_shiro`.`t_materialsauth` `tm1`
      ON (((`te`.`userId` = `tm1`.`userId`) AND (`tm1`.`materAuthTypeId` = 17)))) LEFT JOIN
    `d_shiro`.`t_materialsauth` `tm2`
      ON (((`te`.`userId` = `tm2`.`userId`) AND (`tm2`.`materAuthTypeId` = 18)))) LEFT JOIN
    `d_shiro`.`t_materialsauth` `tm3`
      ON (((`te`.`userId` = `tm3`.`userId`) AND (`tm3`.`materAuthTypeId` = 19)))) LEFT JOIN
    `d_shiro`.`t_materialsauth` `tm4`
      ON (((`te`.`userId` = `tm4`.`userId`) AND (`tm4`.`materAuthTypeId` = 20)))) LEFT JOIN
    `d_shiro`.`t_materialsauth` `tm5`
      ON (((`te`.`userId` = `tm5`.`userId`) AND (`tm5`.`materAuthTypeId` = 21)))) LEFT JOIN
    `d_shiro`.`t_materialsauth` `tm6` ON (((`te`.`userId` = `tm6`.`userId`) AND (`tm6`.`materAuthTypeId` = 22))));
