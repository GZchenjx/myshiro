CREATE VIEW t_user_withdraw_info AS
  SELECT
    `a`.`userId`      AS `userId`,
    `a`.`realName`    AS `realName`,
    `a`.`cellPhone`   AS `cellPhone`,
    `b`.`mobilePhone` AS `bindingPhone`,
    `b`.`status`      AS `status`,
    `d`.`handleSum`   AS `handleSum`,
    `d`.`usableSum`   AS `usableSum`,
    `d`.`freezeSum`   AS `freezeSum`
  FROM ((`d_shiro`.`t_person` `a` LEFT JOIN `d_shiro`.`t_phone_binding_info` `b`
      ON ((`a`.`userId` = `b`.`userId`))) LEFT JOIN `d_shiro`.`t_fundrecord` `d` ON ((`a`.`userId` = `d`.`userId`)));
