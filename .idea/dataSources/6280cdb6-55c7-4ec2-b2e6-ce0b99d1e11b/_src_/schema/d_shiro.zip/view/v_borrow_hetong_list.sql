CREATE VIEW v_borrow_hetong_list AS
  SELECT
    `ti`.`id`                   AS `id`,
    `ti`.`investor`             AS `investor`,
    `ti`.`borrowId`             AS `borrowId`,
    `ti`.`investTime`           AS `investTime`,
    `ti`.`investAmount`         AS `investAmount`,
    `tp1`.`realName`            AS `investName`,
    `tb`.`publisher`            AS `publisher`,
    (CASE WHEN (`tu2`.`busiCode` IS NOT NULL)
      THEN `tu2`.`username`
     ELSE `tp2`.`realName` END) AS `publishName`,
    `tb`.`borrowTitle`          AS `borrowTitle`,
    `ti`.`viewpdf_url`          AS `viewpdf_url`,
    `ti`.`download_url`         AS `download_url`
  FROM ((((`d_shiro`.`t_invest` `ti`
    JOIN `d_shiro`.`t_borrow` `tb`) JOIN `d_shiro`.`t_person` `tp1`) JOIN `d_shiro`.`t_user` `tu2`) JOIN
    `d_shiro`.`t_person` `tp2`)
  WHERE ((`ti`.`borrowId` = `tb`.`id`) AND (`ti`.`investor` = `tp1`.`userId`) AND (`tb`.`publisher` = `tu2`.`id`) AND
         (`tb`.`publisher` = `tp2`.`userId`));
