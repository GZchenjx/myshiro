CREATE VIEW v_tyj_reconciliation_user AS
  SELECT
    `ttr`.`orId`           AS `orId`,
    `ttr`.`stillInterest`  AS `stillInterest`,
    `ttr`.`repayDate`      AS `repayDate`,
    `ttr`.`stillPrincipal` AS `stillPrincipal`,
    `t`.`username`         AS `username`
  FROM (`d_shiro`.`t_exgo_repayment` `ttr`
    JOIN `d_shiro`.`t_user` `t`)
  WHERE (`ttr`.`borrowId` = `t`.`id`);
