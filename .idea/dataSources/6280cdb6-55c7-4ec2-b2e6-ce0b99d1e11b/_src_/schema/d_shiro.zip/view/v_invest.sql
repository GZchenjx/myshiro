CREATE VIEW v_invest AS
  SELECT
    `d_shiro`.`t_invest`.`id`           AS `id`,
    `d_shiro`.`t_invest`.`investAmount` AS `investAmount`,
    `d_shiro`.`t_invest`.`monthRate`    AS `monthRate`,
    `d_shiro`.`t_invest`.`investor`     AS `investor`,
    `d_shiro`.`t_invest`.`borrowId`     AS `borrowId`,
    `d_shiro`.`t_invest`.`investTime`   AS `investTime`,
    `d_shiro`.`t_invest`.`oriInvestor`  AS `oriInvestor`,
    `d_shiro`.`t_invest`.`realAmount`   AS `realAmount`,
    `d_shiro`.`t_borrow`.`borrowTitle`  AS `borrowTitle`,
    `d_shiro`.`t_borrow`.`borrowWay`    AS `borrowWay`,
    `d_shiro`.`t_borrow`.`borrowAmount` AS `borrowAmount`,
    `d_shiro`.`t_borrow`.`borrowStatus` AS `borrowStatus`
  FROM (`d_shiro`.`t_invest`
    JOIN `d_shiro`.`t_borrow` ON ((`d_shiro`.`t_invest`.`borrowId` = `d_shiro`.`t_borrow`.`id`)));
