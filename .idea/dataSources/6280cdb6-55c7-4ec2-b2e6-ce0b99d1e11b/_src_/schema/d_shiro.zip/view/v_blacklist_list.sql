CREATE VIEW v_blacklist_list AS
  SELECT
    `u`.`username`       AS `username`,
    `u`.`id`             AS `id`,
    `u`.`creditrating`   AS `creditrating`,
    `u`.`rating`         AS `rating`,
    `u`.`enable`         AS `enable`,
    `p`.`idNo`           AS `idNo`,
    `p`.`auditStatus`    AS `p_auditStatus`,
    `w`.`auditStatus`    AS `w_auditStatus`,
    `w`.`directedStatus` AS `directedStatus`,
    `w`.`otherStatus`    AS `otherStatus`,
    `w`.`moredStatus`    AS `moredStatus`,
    `b`.`cardStatus`     AS `cardStatus`
  FROM (((`d_shiro`.`t_user` `u` LEFT JOIN `d_shiro`.`t_person` `p` ON ((`u`.`id` = `p`.`userId`))) LEFT JOIN
    `d_shiro`.`t_workauth` `w` ON ((`w`.`userId` = `u`.`id`))) LEFT JOIN `d_shiro`.`t_bankcard` `b`
      ON ((`b`.`userId` = `u`.`id`)));
