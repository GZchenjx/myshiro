CREATE VIEW v_has_invest AS
  SELECT
    `t`.`id`            AS `id`,
    `t`.`borrowId`      AS `borrowId`,
    `tb`.`borrowTitle`  AS `borrowTitle`,
    `tb`.`borrowAmount` AS `borrowAmount`,
    `t`.`investAmount`  AS `investAmount`,
    `tu`.`username`     AS `username`,
    `tb`.`annualRate`   AS `annualRate`,
    `t`.`isAutoBid`     AS `isAutoBid`,
    `t`.`billcode`      AS `billcode`,
    `t`.`investTime`    AS `investTime`
  FROM ((`d_shiro`.`t_borrow` `tb`
    JOIN `d_shiro`.`t_invest` `t`) JOIN `d_shiro`.`t_user` `tu`)
  WHERE ((`tb`.`id` = `t`.`borrowId`) AND (`tb`.`borrowStatus` IN (4, 5)) AND (`t`.`investor` = `tu`.`id`));
