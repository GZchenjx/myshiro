CREATE VIEW v_pr_user AS
  SELECT
    count(0)              AS `counts`,
    sum(`a`.`realAmount`) AS `realAmount`,
    `a`.`investor`        AS `investor`
  FROM (`d_shiro`.`t_invest` `a` LEFT JOIN `d_shiro`.`t_borrow` `b` ON ((`a`.`borrowId` = `b`.`id`)))
  WHERE (`b`.`borrowStatus` IN (4, 5))
  GROUP BY `a`.`investor`;
