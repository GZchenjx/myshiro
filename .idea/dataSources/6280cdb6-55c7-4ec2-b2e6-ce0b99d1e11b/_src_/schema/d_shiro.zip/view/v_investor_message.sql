CREATE VIEW v_investor_message AS
  SELECT
    `e`.`investTime`                                   AS `investTime`,
    `a`.`IpArea`                                       AS `area`,
    left(`a`.`IpArea`, 2)                              AS `IpArea`,
    `b`.`idNo`                                         AS `idNo`,
    (date_format(now(), '%Y') - date_format(
        concat(right(left(`b`.`idNo`, 10), 4), '-', right(left(`b`.`idNo`, 12), 2), '-',
               right(left(`b`.`idNo`, 14), 2)), '%Y')) AS `age`
  FROM ((`d_shiro`.`t_user` `a` LEFT JOIN `d_shiro`.`t_person` `b` ON ((`a`.`id` = `b`.`userId`))) LEFT JOIN
    `d_shiro`.`t_invest` `e` ON ((`a`.`id` = `e`.`investor`)))
  GROUP BY `e`.`investor`;
