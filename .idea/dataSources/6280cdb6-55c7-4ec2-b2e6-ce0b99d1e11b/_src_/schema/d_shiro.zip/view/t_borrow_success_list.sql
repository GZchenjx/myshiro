CREATE VIEW t_borrow_success_list AS
  SELECT
    `c`.`id`                                                          AS `id`,
    `c`.`borrowTitle`                                                 AS `borrowTitle`,
    `c`.`borrowWay`                                                   AS `borrowWay`,
    `c`.`borrowAmount`                                                AS `borrowAmount`,
    `c`.`annualRate`                                                  AS `annualRate`,
    `c`.`deadline`                                                    AS `deadline`,
    `c`.`publishTime`                                                 AS `publishTime`,
    `c`.`publisher`                                                   AS `publisher`,
    `c`.`borrowStatus`                                                AS `borrowStatus`,
    `c`.`paymentMode`                                                 AS `paymentMode`,
    `c`.`isDayThe`                                                    AS `isDayThe`,
    `a`.`borrowId`                                                    AS `borrowId`,
    `c`.`borrowShow`                                                  AS `borrowShow`,
    `c`.`borrowTypeSubId`                                             AS `borrowTypeSubId`,
    `b`.`name`                                                        AS `borrowWayName`,
    sum((`a`.`stillPrincipal` + `a`.`stillInterest`))                 AS `stillTotalSum`,
    sum(`a`.`hasPI`)                                                  AS `hasPI`,
    sum(((`a`.`stillPrincipal` + `a`.`stillInterest`) - `a`.`hasPI`)) AS `hasSum`,
    `a`.`hasFI`                                                       AS `hasFI`,
    `c`.`auditTime`                                                   AS `auditTime`
  FROM ((`d_shiro`.`t_borrow` `c` LEFT JOIN `d_shiro`.`t_repayment` `a` ON ((`c`.`id` = `a`.`borrowId`))) LEFT JOIN
    `d_shiro`.`t_borrow_sub_type` `b` ON ((`c`.`borrowTypeSubId` = `b`.`id`)))
  GROUP BY `c`.`id`;
