CREATE VIEW v_query_reconciliation AS
  SELECT
    `a`.`id`             AS `id`,
    `a`.`ordId`          AS `ordId`,
    `b`.`username`       AS `merCustId`,
    `c`.`username`       AS `investCustId`,
    `d`.`username`       AS `borrCustId`,
    `a`.`transAmt`       AS `transAmt`,
    `a`.`transStat`      AS `transStat`,
    `a`.`pnrDate`        AS `pnrDate`,
    `a`.`pnrSeqId`       AS `pnrSeqId`,
    `a`.`queryTransType` AS `queryTransType`,
    `a`.`ordDate`        AS `ordDate`
  FROM (((`d_shiro`.`t_release_also_reconciliation` `a` LEFT JOIN `d_shiro`.`t_user` `b`
      ON ((`a`.`merCustId` = `b`.`ipayAccount`))) LEFT JOIN `d_shiro`.`t_user` `c`
      ON ((`a`.`investCustId` = `c`.`ipayAccount`))) LEFT JOIN `d_shiro`.`t_user` `d`
      ON ((`a`.`borrCustId` = `d`.`ipayAccount`)));
