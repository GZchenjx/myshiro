CREATE VIEW v_admin_assignment_debt_borrow AS
  SELECT
    `d_shiro`.`t_assignment_debt`.`id`                                                                       AS `id`,
    `d_shiro`.`t_assignment_debt`.`debtSum`                                                                  AS `debtSum`,
    `d_shiro`.`t_assignment_debt`.`auctionBasePrice`                                                         AS `auctionBasePrice`,
    `d_shiro`.`t_invest`.`realAmount`                                                                        AS `realAmount`,
    `d_shiro`.`t_assignment_debt`.`debtStatus`                                                               AS `debtStatus`,
    `d_shiro`.`t_assignment_debt`.`publishTime`                                                              AS `publishTime`,
    `d_shiro`.`t_assignment_debt`.`debtLimit`                                                                AS `debtLimit`,
    `d_shiro`.`t_user`.`username`                                                                            AS `alienatorName`,
    `d_shiro`.`t_user`.`vipStatus`                                                                           AS `vipStatus`,
    `d_shiro`.`t_borrow`.`borrowTitle`                                                                       AS `borrowTitle`,
    `d_shiro`.`t_borrow`.`id`                                                                                AS `borrowId`,
    `d_shiro`.`t_borrow`.`borrowWay`                                                                         AS `borrowWay`,
    `d_shiro`.`t_borrow`.`deadline`                                                                          AS `deadline`,
    `d_shiro`.`t_borrow`.`annualRate`                                                                        AS `annualRate`,
    `borrower`.`username`                                                                                    AS `borrowerName`,
    `auctioner`.`username`                                                                                   AS `auctionerName`,
    `d_shiro`.`t_assignment_debt`.`auctionEndTime`                                                           AS `auctionEndTime`,
    (`d_shiro`.`t_assignment_debt`.`publishTime` +
     INTERVAL `d_shiro`.`t_assignment_debt`.`auctionDays` DAY)                                               AS `remainAuctionTime`,
    `d_shiro`.`t_assignment_debt`.`auctionHighPrice`                                                         AS `auctionHighPrice`
  FROM (((((`d_shiro`.`t_assignment_debt`
    LEFT JOIN `d_shiro`.`t_invest`
      ON ((`d_shiro`.`t_assignment_debt`.`investId` = `d_shiro`.`t_invest`.`id`))) LEFT JOIN `d_shiro`.`t_user`
      ON ((`d_shiro`.`t_assignment_debt`.`alienatorId` = `d_shiro`.`t_user`.`id`))) LEFT JOIN `d_shiro`.`t_borrow`
      ON ((`d_shiro`.`t_assignment_debt`.`borrowId` = `d_shiro`.`t_borrow`.`id`))) LEFT JOIN
    `d_shiro`.`t_user` `borrower` ON ((`d_shiro`.`t_borrow`.`publisher` = `borrower`.`id`))) LEFT JOIN
    `d_shiro`.`t_user` `auctioner` ON ((`auctioner`.`id` = `d_shiro`.`t_assignment_debt`.`auctionerId`)));
