CREATE VIEW v_pay_repayment AS
  SELECT
    `tu`.`id`                AS `id`,
    `tu`.`ipayAccount`       AS `ipayAccount`,
    `tir`.`recivedPrincipal` AS `recivedPrincipal`,
    `tir`.`recivedInterest`  AS `recivedInterest`,
    `tir`.`owner`            AS `investorId`,
    `tir`.`invest_id`        AS `invest_id`,
    `tir`.`id`               AS `repaymentId`,
    `tu`.`password`          AS `password`,
    `tu`.`username`          AS `username`,
    `tb`.`id`                AS `borrowId`,
    `tb`.`borrowTitle`       AS `borrowTitle`
  FROM ((`d_shiro`.`t_user` `tu`
    JOIN `d_shiro`.`t_borrow` `tb`) JOIN `d_shiro`.`t_invest_repayment` `tir`)
  WHERE ((`tu`.`id` = `tb`.`publisher`) AND (`tb`.`id` = `tir`.`borrow_id`) AND (`tir`.`repayStatus` = 1));
