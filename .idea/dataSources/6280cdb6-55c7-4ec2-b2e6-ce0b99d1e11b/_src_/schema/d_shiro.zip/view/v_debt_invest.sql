CREATE VIEW v_debt_invest AS
  SELECT
    `d_shiro`.`t_repayment`.`repayDate`                                                     AS `repayDate`,
    `d_shiro`.`t_repayment`.`realRepayDate`                                                 AS `realRepayDate`,
    round(
        (`d_shiro`.`t_repayment`.`hasFI` * (`d_shiro`.`t_invest`.`investAmount` / `d_shiro`.`t_borrow`.`borrowAmount`)),
        2)                                                                                  AS `hasFI`,
    round((`d_shiro`.`t_repayment`.`investorForpayFI` *
           (`d_shiro`.`t_invest`.`investAmount` / `d_shiro`.`t_borrow`.`borrowAmount`)), 2) AS `investorForpayFI`,
    round((`d_shiro`.`t_repayment`.`investorHaspayFI` *
           (`d_shiro`.`t_invest`.`investAmount` / `d_shiro`.`t_borrow`.`borrowAmount`)), 2) AS `investorHaspayFI`,
    round(
        (`d_shiro`.`t_repayment`.`hasPI` * (`d_shiro`.`t_invest`.`investAmount` / `d_shiro`.`t_borrow`.`borrowAmount`)),
        2)                                                                                  AS `hasPI`,
    `d_shiro`.`t_repayment`.`borrowId`                                                      AS `borrowId`,
    `d_shiro`.`t_invest`.`investor`                                                         AS `investor`,
    `d_shiro`.`t_invest`.`id`                                                               AS `investId`,
    round(((`d_shiro`.`t_repayment`.`stillPrincipal` + `d_shiro`.`t_repayment`.`stillInterest`) *
           (`d_shiro`.`t_invest`.`investAmount` / `d_shiro`.`t_borrow`.`borrowAmount`)), 2) AS `stillPI`
  FROM ((`d_shiro`.`t_repayment`
    LEFT JOIN `d_shiro`.`t_borrow` ON ((`d_shiro`.`t_borrow`.`id` = `d_shiro`.`t_repayment`.`borrowId`))) LEFT JOIN
    `d_shiro`.`t_invest` ON ((`d_shiro`.`t_invest`.`borrowId` = `d_shiro`.`t_repayment`.`borrowId`)))
  WHERE isnull(`d_shiro`.`t_repayment`.`realRepayDate`);
