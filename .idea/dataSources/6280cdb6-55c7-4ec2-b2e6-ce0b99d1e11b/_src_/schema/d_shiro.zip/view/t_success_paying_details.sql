CREATE VIEW t_success_paying_details AS
  SELECT
    `d_shiro`.`t_repayment`.`id`                                                                               AS `id`,
    date_format(`d_shiro`.`t_repayment`.`repayDate`,
                '%Y-%m-%d')                                                                                    AS `repayDate`,
    `d_shiro`.`t_repayment`.`borrowId`                                                                         AS `borrowId`,
    ((`d_shiro`.`t_repayment`.`stillInterest` + `d_shiro`.`t_repayment`.`stillPrincipal`) -
     `d_shiro`.`t_repayment`.`hasPI`)                                                                          AS `repayTotal`,
    date_format(`d_shiro`.`t_repayment`.`realRepayDate`,
                '%Y-%m-%d')                                                                                    AS `realRepayDate`,
    `d_shiro`.`t_repayment`.`lateDay`                                                                          AS `lateDay`,
    `d_shiro`.`t_repayment`.`hasPI`                                                                            AS `hasPI`,
    (`d_shiro`.`t_repayment`.`lateFI` -
     `d_shiro`.`t_repayment`.`hasFI`)                                                                          AS `lateTotal`,
    ((((`d_shiro`.`t_repayment`.`stillInterest` + `d_shiro`.`t_repayment`.`stillPrincipal`) -
       `d_shiro`.`t_repayment`.`hasPI`) + `d_shiro`.`t_repayment`.`lateFI`) -
     `d_shiro`.`t_repayment`.`hasFI`)                                                                          AS `total`,
    `d_shiro`.`t_repayment`.`repayStatus`                                                                      AS `repayStatus`,
    `d_shiro`.`t_repayment`.`repayPeriod`                                                                      AS `repayPeriod`,
    (`d_shiro`.`t_repayment`.`stillInterest` +
     `d_shiro`.`t_repayment`.`stillPrincipal`)                                                                 AS `forPI`,
    `d_shiro`.`t_repayment`.`isLate`                                                                           AS `isLate`
  FROM `d_shiro`.`t_repayment`;
