CREATE VIEW v_t_assignment_debt_username AS
  SELECT
    `a`.`id`               AS `id`,
    `a`.`debtSum`          AS `debtSum`,
    `a`.`debtStatus`       AS `debtStatus`,
    `a`.`borrowId`         AS `borrowId`,
    `a`.`alienatorId`      AS `alienatorId`,
    `b`.`idNo`             AS `idNo`,
    `b`.`realName`         AS `realName`,
    `c`.`username`         AS `username`,
    `c`.`id`               AS `cid`,
    `f`.`id`               AS `fid`,
    `d`.`idNo`             AS `dbisno`,
    `d`.`realName`         AS `dbrealName`,
    `f`.`username`         AS `dbusername`,
    `a`.`auctionerId`      AS `dbauctionerId`,
    `a`.`investId`         AS `investId`,
    `a`.`auctionEndTime`   AS `auctionEndTime`,
    `a`.`debtLimit`        AS `debtLimit`,
    `a`.`auctionHighPrice` AS `auctionHighPrice`,
    `a`.`manageFee`        AS `manageFee`
  FROM ((((`d_shiro`.`t_assignment_debt` `a` LEFT JOIN `d_shiro`.`t_person` `b`
      ON ((`a`.`alienatorId` = `b`.`userId`))) LEFT JOIN `d_shiro`.`t_user` `c`
      ON ((`a`.`alienatorId` = `c`.`id`))) LEFT JOIN `d_shiro`.`t_person` `d`
      ON ((`a`.`auctionerId` = `d`.`userId`))) LEFT JOIN `d_shiro`.`t_user` `f` ON ((`a`.`auctionerId` = `f`.`id`)))
  WHERE (`a`.`debtStatus` = 3);
