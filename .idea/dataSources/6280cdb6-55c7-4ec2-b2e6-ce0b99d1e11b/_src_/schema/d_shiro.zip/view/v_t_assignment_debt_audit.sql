CREATE VIEW v_t_assignment_debt_audit AS
  SELECT
    `d_shiro`.`t_assignment_debt`.`id`                        AS `id`,
    `d_shiro`.`t_assignment_debt`.`borrowId`                  AS `borrowId`,
    `d_shiro`.`t_assignment_debt`.`debtSum`                   AS `debtSum`,
    `d_shiro`.`t_assignment_debt`.`auctionBasePrice`          AS `auctionBasePrice`,
    `d_shiro`.`t_assignment_debt`.`debtStatus`                AS `debtStatus`,
    `d_shiro`.`t_user`.`username`                             AS `borrowerName`,
    `alinator`.`username`                                     AS `alienatorName`,
    `d_shiro`.`t_borrow`.`borrowTitle`                        AS `borrowTitle`,
    `d_shiro`.`t_borrow`.`annualRate`                         AS `annualRate`,
    `d_shiro`.`t_assignment_debt`.`debtLimit`                 AS `debtLimit`,
    `d_shiro`.`t_borrow`.`paymentMode`                        AS `paymentMode`,
    `d_shiro`.`t_borrow`.`borrowWay`                          AS `borrowWay`,
    (CASE WHEN ((SELECT count(1) AS `count(1)`
                 FROM `d_shiro`.`t_repayment`
                 WHERE ((`d_shiro`.`t_repayment`.`borrowId` = `d_shiro`.`t_assignment_debt`.`borrowId`) AND
                        (`d_shiro`.`t_repayment`.`isLate` = 2))) > 0)
      THEN 2
     ELSE 1 END)                                              AS `isLate`,
    (SELECT min(`d_shiro`.`t_repayment`.`repayDate`) AS `min(``t_repayment``.``repayDate``)`
     FROM `d_shiro`.`t_repayment`
     WHERE ((`d_shiro`.`t_repayment`.`borrowId` = `d_shiro`.`t_assignment_debt`.`borrowId`) AND
            isnull(`d_shiro`.`t_repayment`.`realRepayDate`))) AS `repayDate`,
    `d`.`id`                                                  AS `borrowTypeSubId`,
    `d`.`name`                                                AS `borrowWayName`
  FROM ((((`d_shiro`.`t_assignment_debt`
    LEFT JOIN `d_shiro`.`t_borrow`
      ON ((`d_shiro`.`t_assignment_debt`.`borrowId` = `d_shiro`.`t_borrow`.`id`))) LEFT JOIN `d_shiro`.`t_user`
      ON ((`d_shiro`.`t_borrow`.`publisher` = `d_shiro`.`t_user`.`id`))) LEFT JOIN `d_shiro`.`t_user` `alinator`
      ON ((`d_shiro`.`t_assignment_debt`.`alienatorId` = `alinator`.`id`))) LEFT JOIN `d_shiro`.`t_borrow_sub_type` `d`
      ON ((`d`.`id` = `d_shiro`.`t_borrow`.`borrowTypeSubId`)));
