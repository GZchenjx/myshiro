CREATE VIEW t_fundrecord_list AS
  SELECT
    `a`.`id`         AS `id`,
    `a`.`userId`     AS `userId`,
    `a`.`fundMode`   AS `fundMode`,
    `a`.`handleSum`  AS `handleSum`,
    `a`.`usableSum`  AS `usableSum`,
    `a`.`freezeSum`  AS `freezeSum`,
    `a`.`dueinSum`   AS `dueinSum`,
    `a`.`trader`     AS `trader`,
    `a`.`recordTime` AS `recordTime`,
    `a`.`dueoutSum`  AS `dueoutSum`,
    `b`.`username`   AS `username`
  FROM (`d_shiro`.`t_fundrecord` `a` LEFT JOIN `d_shiro`.`t_user` `b` ON ((`a`.`trader` = `b`.`id`)));
