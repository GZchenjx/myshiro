CREATE VIEW v_debt_aucting_borrow AS
  SELECT
    `d_shiro`.`t_auction_debt`.`userId`                                                                        AS `userId`,
    `d_shiro`.`t_auction_debt`.`debtId`                                                                        AS `debtId`,
    `d_shiro`.`t_auction_debt`.`auctionTime`                                                                   AS `auctionTime`,
    `d_shiro`.`t_auction_debt`.`auctionPrice`                                                                  AS `auctionPrice`,
    `d_shiro`.`t_assignment_debt`.`alienatorId`                                                                AS `alienatorId`,
    `d_shiro`.`t_assignment_debt`.`debtLimit`                                                                  AS `debtLimit`,
    `d_shiro`.`t_assignment_debt`.`debtSum`                                                                    AS `debtSum`,
    `d_shiro`.`t_assignment_debt`.`auctionHighPrice`                                                           AS `auctionHighPrice`,
    `d_shiro`.`t_assignment_debt`.`auctionBasePrice`                                                           AS `auctionBasePrice`,
    `alienator`.`username`                                                                                     AS `username`,
    `d_shiro`.`t_borrow`.`borrowTitle`                                                                         AS `borrowTitle`,
    `d_shiro`.`t_user`.`username`                                                                              AS `borrowerName`,
    `d_shiro`.`t_assignment_debt`.`debtStatus`                                                                 AS `debtStatus`,
    `d_shiro`.`t_borrow`.`annualRate`                                                                          AS `annualRate`,
    `d_shiro`.`t_borrow`.`deadline`                                                                            AS `deadline`,
    `d_shiro`.`t_borrow`.`borrowAmount`                                                                        AS `borrowAmount`,
    `d_shiro`.`t_borrow`.`paymentMode`                                                                         AS `paymentMode`,
    `d_shiro`.`t_borrow`.`borrowWay`                                                                           AS `borrowWay`,
    `d_shiro`.`t_borrow`.`id`                                                                                  AS `borrowId`,
    (SELECT count(1) AS `count(1)`
     FROM `d_shiro`.`t_auction_debt` `t_a`
     WHERE ((`t_a`.`debtId` = `d_shiro`.`t_auction_debt`.`debtId`) AND (`t_a`.`userId` =
                                                                        `d_shiro`.`t_auction_debt`.`userId`))) AS `auctionCount`,
    (`d_shiro`.`t_assignment_debt`.`publishTime` +
     INTERVAL `d_shiro`.`t_assignment_debt`.`auctionDays` DAY)                                                 AS `remainAuctionTime`
  FROM ((((`d_shiro`.`t_auction_debt`
    LEFT JOIN `d_shiro`.`t_assignment_debt`
      ON ((`d_shiro`.`t_auction_debt`.`debtId` = `d_shiro`.`t_assignment_debt`.`id`))) LEFT JOIN `d_shiro`.`t_borrow`
      ON ((`d_shiro`.`t_assignment_debt`.`borrowId` = `d_shiro`.`t_borrow`.`id`))) LEFT JOIN `d_shiro`.`t_user`
      ON ((`d_shiro`.`t_borrow`.`publisher` = `d_shiro`.`t_user`.`id`))) LEFT JOIN `d_shiro`.`t_user` `alienator`
      ON ((`d_shiro`.`t_assignment_debt`.`alienatorId` = `alienator`.`id`)));
