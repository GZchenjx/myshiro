CREATE VIEW t_success_borrow_details AS
  SELECT
    `c`.`publisher`                                                   AS `publisher`,
    `c`.`borrowTitle`                                                 AS `borrowTitle`,
    `b`.`borrowId`                                                    AS `borrowId`,
    `a`.`investor`                                                    AS `investor`,
    `a`.`realAmount`                                                  AS `realAmount`,
    sum((`b`.`stillInterest` + `b`.`stillPrincipal`))                 AS `payTotal`,
    sum(((`b`.`stillInterest` + `b`.`stillPrincipal`) - `b`.`hasPI`)) AS `remainTotal`
  FROM ((`d_shiro`.`t_invest` `a` LEFT JOIN `d_shiro`.`t_borrow` `c` ON ((`c`.`id` = `a`.`borrowId`))) LEFT JOIN
    `d_shiro`.`t_repayment` `b` ON ((`c`.`id` = `b`.`borrowId`)))
  GROUP BY `c`.`id`;
