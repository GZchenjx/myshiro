CREATE VIEW v_t_amount_record AS
  SELECT
    `a`.`id`                                                                                                       AS `id`,
    (`a`.`usableSum` +
     `a`.`freezeSum`)                                                                                              AS `totalSum`,
    `a`.`usableSum`                                                                                                AS `usableSum`,
    `a`.`freezeSum`                                                                                                AS `freezeSum`,
    ifnull(sum((((`b`.`recivedPrincipal` + `b`.`recievedInterest`) - `b`.`hasPrincipal`) - `b`.`hasInterest`)),
           0)                                                                                                      AS `forPI`
  FROM (`d_shiro`.`t_user` `a` LEFT JOIN `d_shiro`.`t_invest` `b` ON ((`a`.`id` = `b`.`investor`)))
  GROUP BY `a`.`id`;
