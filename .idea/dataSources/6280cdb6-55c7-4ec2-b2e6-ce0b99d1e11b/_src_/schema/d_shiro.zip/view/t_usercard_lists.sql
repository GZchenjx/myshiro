CREATE VIEW t_usercard_lists AS
  SELECT
    `a`.`id`                     AS `id`,
    `a`.`cardUserName`           AS `cardUserName`,
    `a`.`bankName`               AS `bankName`,
    `a`.`branchBankName`         AS `branchBankName`,
    `a`.`cardNo`                 AS `cardNo`,
    `a`.`cardMode`               AS `cardMode`,
    `a`.`modifiedCardNo`         AS `modifiedCardNo`,
    `a`.`modifiedBankName`       AS `modifiedBankName`,
    `a`.`modifiedBranchBankName` AS `modifiedBranchBankName`,
    `a`.`commitTime`             AS `commitTime`,
    `a`.`modifiedTime`           AS `modifiedTime`,
    `a`.`cardStatus`             AS `cardStatus`,
    `a`.`checkTime`              AS `checkTime`,
    `a`.`userId`                 AS `userId`,
    `a`.`checkUser`              AS `checkUser`,
    `b`.`realName`               AS `realName`,
    `b`.`idNo`                   AS `idNo`,
    `b`.`cellPhone`              AS `cellPhone`,
    `d`.`mobilePhone`            AS `mobilePhone`,
    `c`.`username`               AS `username`
  FROM (((`d_shiro`.`t_bankcard` `a` LEFT JOIN `d_shiro`.`t_person` `b` ON ((`a`.`userId` = `b`.`userId`))) LEFT JOIN
    `d_shiro`.`t_user` `c` ON ((`a`.`userId` = `c`.`id`))) LEFT JOIN `d_shiro`.`t_phone_binding_info` `d`
      ON ((`a`.`userId` = `d`.`userId`)))
  GROUP BY `c`.`username`;
